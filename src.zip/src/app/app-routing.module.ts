import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MatchesComponent } from './matches/matches.component';
import { WinnerListComponent } from './winner-list/winner-list.component';
import { LiveMatchesComponent } from './live-matches/live-matches.component';
import { TestComponent } from './test/test.component';

const routes: Routes = [
{path :'login'   , component: LoginComponent},
{path :'matches' , component: MatchesComponent},
{path :'winner'  ,  component: WinnerListComponent},
{path :'l_match'  ,  component: LiveMatchesComponent},
{path :'test'  ,  component: TestComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingcomponent = [LoginComponent,MatchesComponent,WinnerListComponent,LiveMatchesComponent,TestComponent]