import { TestBed } from '@angular/core/testing';

import { CongifserviceService } from './congifservice.service';

describe('CongifserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CongifserviceService = TestBed.get(CongifserviceService);
    expect(service).toBeTruthy();
  });
});
