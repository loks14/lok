import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DwaruComponent } from './dwaru.component';

describe('DwaruComponent', () => {
  let component: DwaruComponent;
  let fixture: ComponentFixture<DwaruComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DwaruComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DwaruComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
