import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-winner-list',
  templateUrl: './winner-list.component.html',
  styleUrls: ['./winner-list.component.css']
})
export class WinnerListComponent implements OnInit {

 api_data_fantasy=null;
 
  constructor(http:HttpClient) {
  http.get("https://api.dotball.com/api/match").
  subscribe((data)=>{
    console.log("data 1");
    this.api_data_fantasy=data;
    console.log(data);
    
  });
}
match_id(event){
 alert(event.target.id);
}
   ngOnInit() {
  }
}
